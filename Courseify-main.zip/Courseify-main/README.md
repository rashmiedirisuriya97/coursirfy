# Courseify
Mini_Project

Frontend:
```cd frontend```
```npm install```
```npm start```

Backend:
```cd Admin```
```cd admin_backend```
```node server.js```
